#include<iostream>
#include<conio.h>
using namespace std;

float fraccionario();

int main(){
	float n=fraccionario();
    cout<<n;

	getch();
    return 0;
}

float fraccionario(){
	float n;
    cout<<"Ingrese numero para encontrar fracionario: ";
    cin>>n;
    int n2=n;
    if (n>1){
    	n=n-n2;
    } 
    
    return n;
}