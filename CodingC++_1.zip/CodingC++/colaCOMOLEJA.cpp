//hacer un programa que almacene los
//datos de los clientes de un banco, los almacene 
//en una cola, y por ultimo muestre el orden de los
//clientes en orden correcto.

#include<iostream>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
using namespace std;

struct Nodo{
	int dato;
    char nombre[30];
    float saldo;
    Nodo *siguiente;
};

//prototipos
void insertarCola(Nodo *&frente, Nodo *&fin, int n, char cm[30], float s);
bool cola_vacia(Nodo *frente);
void suprimirCola(Nodo *&frente, Nodo *&fin, int &n, char cm[30], float &s);

int main(){
	//varibles prioritarias de la estructura
	Nodo *frente=NULL;
    Nodo *fin=NULL;
    
    //variable de la cantidad
    int n;
    
    //variables de los datos
    int dato;
    char nombre[30];
    float saldo;
    
    cout << "Ingrese cantidad de usuarios: " << endl;
    cin>>n;
    
    for(int i = 0; i < n; i++){
    	fflush(stdin);
   	 cout<<"Digite un numero: ";
  	  cin>>dato;
        cin.ignore();
   	 cout<<"Digite un nombre: ";
 	   cin.getline(nombre, 30);
  	  cout<<"Digite un saldo: ";
   	 cin>>saldo;
 	   insertarCola(frente, fin, dato, nombre, saldo);
        cout << "\n\n" << endl;
    }
    
    while(frente != NULL){
    	suprimirCola(frente, fin, dato, nombre, saldo);
        
        cout<<"Usuario: "<<dato<<"\nNombre: "<<nombre<<"\nSaldo: "<<saldo<<"\n\n";
    }
    
    getch();
    return 0;
}

//Funcio para insetar elementos en la cola
void insertarCola(Nodo *&frente, Nodo *&fin, int n, char cm[30], float s){
	Nodo *nuevo_nodo=new Nodo();
    
    nuevo_nodo->dato=n;
    strcpy(nuevo_nodo->nombre, cm);
    nuevo_nodo->saldo=s;
    
    nuevo_nodo->siguiente=NULL;
    
    if(cola_vacia(frente)){
    	frente=nuevo_nodo;
    }
    else {
    	fin->siguiente=nuevo_nodo;
    }
    
    fin=nuevo_nodo;
}

bool cola_vacia(Nodo *frente){
	return (frente==NULL)?true:false;
}

void suprimirCola(Nodo *&frente, Nodo *&fin, int &n, char cm[30], float &s){
	n=frente->dato;
    s=frente->saldo;
    strcpy(cm, frente->nombre);
    
    Nodo *aux=frente;
    
    if(frente==fin){
    	frente=NULL;
        fin=NULL;
    }
    else{
    	frente=frente->siguiente;
    }
    delete aux;    
}