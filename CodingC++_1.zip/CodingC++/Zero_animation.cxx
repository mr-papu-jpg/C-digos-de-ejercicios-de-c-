 #include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <iostream>

const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;

// Ajusta esto al tamaño de cada sprite individual
const int FRAME_WIDTH = 45;
const int FRAME_HEIGHT = 53;
const int TOTAL_FRAMES = 12; // Modifica según la cantidad de frames en una fila

SDL_Window* window = nullptr;
SDL_Renderer* renderer = nullptr;
SDL_Texture* spriteSheet = nullptr;

bool init() {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) return false;

    window = SDL_CreateWindow("Animación Sprite", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (IMG_Init(IMG_INIT_PNG)!=false)
    return true;
}

bool loadMedia(const char* path) {
    spriteSheet = IMG_LoadTexture(renderer, path);
    return spriteSheet != nullptr;
}

void close() {
    SDL_DestroyTexture(spriteSheet);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();
}

void renderFrame(int frameIndex, int posX, int posY, int tamano) {
    SDL_Rect src = { frameIndex * FRAME_WIDTH, 0, FRAME_WIDTH, FRAME_HEIGHT };
    SDL_Rect dst = { posX, posY, FRAME_WIDTH*tamano, FRAME_HEIGHT*tamano};
    SDL_RenderCopy(renderer, spriteSheet, &src, &dst);
}

int main(int argc, char* argv[]) {
    if (!init()) return -1;
    if (!loadMedia("/storage/emulated/0/Download/pngwing.com.png")) return -1; // Usa la ruta a tu imagen aquí

    bool quit = false;
    SDL_Event e;
    int frame = 0;
    Uint32 lastTime = SDL_GetTicks();

    while (!quit) {
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) quit = true;
        }

        Uint32 currentTime = SDL_GetTicks();
        if (currentTime - lastTime >= 150) { // Cambia cada 150ms
            frame = (frame + 1) % TOTAL_FRAMES;
            lastTime = currentTime;
        }

        SDL_SetRenderDrawColor(renderer, 30, 30, 30, 255);
        SDL_RenderClear(renderer);

      renderFrame(frame, SCREEN_WIDTH / 2 - FRAME_WIDTH / 2-100, SCREEN_HEIGHT / 2 - FRAME_HEIGHT / 2, 5);

        SDL_RenderPresent(renderer);
    }

    close();
    return 0;
}