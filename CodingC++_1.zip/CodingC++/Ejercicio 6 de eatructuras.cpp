#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

/*Ejercicio 6: Utilizar las 2 estructuras del 
problema 5, pero ahora pedir los datos para 
N alumnos, y calcular cuál de todos tiene el 
mejor promedio, e imprimir sus datos.
*/

struct promedio{
	float nota1;
    float nota2;
    float nota3;
};

struct alumno{
	char nombre[20];
    char sexo[20];
    int edad;
    struct promedio promd;
}alumno[100];

int main(){
	float prodems[20];
    int n;
    cout<<"Intrpduzca cantidad de alumnos"<<endl; cin>>n;
    cout<<"Programa para sacar promedio de un alumno:\n -_-_-_-_-\n";
 
    for(int i=0; i<n; i++){
    	fflush(stdin);
        getch();
		cout<<"Introdusca el nombre:"<<endl; cin.getline(alumno[i].nombre, 20, '\n');
        cout<<"Introduzca sexo"<<endl; cin.getline(alumno[i].sexo, 20, '\n');
  	  cout<<"Introduzca edad"<<endl; cin>>alumno[i].edad;
  	  cout << "introduzca todo su promedio" << endl;
 	   cout << "<1>=" << endl;
  	  cin>>alumno[i].promd.nota1;
 	   cout << "~~~~~~" << endl;
	    cout << "<2>=" << endl;
	    cin>>alumno[i].promd.nota2;
 	   cout << "~~~~~~" << endl;
  	  cout << "<3>=" << endl;
   	 cin>>alumno[i].promd.nota3;
    	cout << "~~~~~~" << endl;
  	  prodems[i] =(alumno[i].promd.nota1+alumno[i].promd.nota2+alumno[i].promd.nota3)/3;
    };
    
   for(int i=0; i<n; i++){
	    cout << "impresion de datos: " << endl;
 	   cout << "~~~~~~" << endl;
  	  cout << "NOMBRE: " <<alumno[i].nombre<< endl;
   	 cout << "~~~~~~" << endl;
    	cout << "SEXO: " <<alumno[i].sexo<< endl;
 	   cout << "~~~~~~" << endl;
  	  cout << "EDAD: " <<alumno[i].edad<< endl;
   	 cout << "~~~~~~" << endl;
  	  cout << "PROMEDIO: " <<prodems[i]<< endl;
   };
   
   //codigobpara enc)ntrar el promediobmayor
   float prom_may;
   int pos_may;
   for(int i=0; i<n; i++){
  	if(prodems[i]>prodems[i+1]){
      	prom_may= prodems[i];
          pos_may= i;
      };
   };
   
   cout<<"El alumno con nota mayor es: "<<alumno[pos_may].nombre<<" con: \n"<< prom_may<<endl;
   getch();
   return 0;
};