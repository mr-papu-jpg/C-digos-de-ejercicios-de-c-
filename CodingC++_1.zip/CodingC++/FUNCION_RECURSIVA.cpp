#include<iostream>
#include<conio.h>
using namespace std;

int fibonachi(int n);

int main(){
	int n;
    cout << "Ingrese el numero: " << endl;
    cin>>n;
    cout << "\n\n" << endl;
    
    fibonachi(n);
    
    getch();
    return 0;
}

int fibonachi(int n){
    if(n==1){
        n=1;
        cout << n << endl;
    }
    else
    {
    	n=n + fibonachi(n-1);
        cout << n << endl;
    }
    return n;   
}