#include <SDL2/SDL.h>

int main(int argc, char* argv[]) {
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Window* window = SDL_CreateWindow("Triángulo en SDL2",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        640, 480, SDL_WINDOW_SHOWN);
    
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // Fondo blanco
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    SDL_RenderClear(renderer);

  SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); // Rojo
  SDL_Point puntos[] = {{50,50}, {600,50}, {600,150}, {50,150}, {50,50}};
SDL_RenderDrawLines(renderer, puntos, 5);

  SDL_SetRenderDrawColor(renderer, 255, 255, 0, 255); // Amarillo
SDL_Rect rect = {10, 1000, 600, 250};
SDL_RenderDrawRect(renderer, &rect);       // Solo el borde
SDL_RenderFillRect(renderer, &rect);       // Rectángulo relleno


    SDL_RenderPresent(renderer);

    SDL_Delay(5000); // Mantener ventana abierta por 5 segundos

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}