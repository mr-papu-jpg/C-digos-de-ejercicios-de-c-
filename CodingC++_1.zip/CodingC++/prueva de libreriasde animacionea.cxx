#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/libreria de sprites/Animation.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/libreria de sprites/Sprites.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/libreria de sprites/Sprites.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/libreria de sprites/Animation.cpp"

int main(int argc, char* argv[]) {
    SDL_Init(SDL_INIT_VIDEO);
    IMG_Init(IMG_INIT_PNG);

    SDL_Window* window = SDL_CreateWindow("Animación", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 800, 600, 0);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // Crea sprite
    Sprite* sprite = new Sprite(renderer, "/storage/3807-15EE/DCIM/frames/moneda_simple - Copiar.png", 64, 64, 1);
    sprite->setPosition(200, 250);
    sprite->setScale(2.0f, 2.0f); // Escala 2x

    // Crea animación
    Animation* anim = new Animation(sprite, 7, 100); // 7 frames, cada 100ms

    bool running = true;
    SDL_Event e;

    while (running) {
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT)
                running = false;
        }

        anim->update();

        SDL_RenderClear(renderer);
        anim->render();
        SDL_RenderPresent(renderer);
        SDL_Delay(16); // ~60FPS
    }

    delete anim;
    delete sprite;
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();
    return 0;
}