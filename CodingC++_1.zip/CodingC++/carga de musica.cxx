#include <SDL2/SDL.h>
#include<SDL2/SDL_mixer.h>

int main(int argc, char* argv[]) {
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Window* window = SDL_CreateWindow("Triángulo en SDL2",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        640, 480, SDL_WINDOW_SHOWN);
    
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);


  SDL_Surface* surface = SDL_LoadBMP("/storage/3807-15EE/Codigos/c++/proyectos de SDL/Nave-jugador.bmp");
SDL_Texture* textura = SDL_CreateTextureFromSurface(renderer, surface);
SDL_FreeSurface(surface);

SDL_Rect destino = {30, 200, 64, 64}; // Posición y tamaño en pantalla
SDL_RenderCopy(renderer, textura, NULL, &destino);

       SDL_RenderPresent(renderer);
       
       Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);
    Mix_Music* musica = Mix_LoadMUS("/storage/3807-15EE/Music/black clover/y2mate.com - Black Clover Ending 13 FullBEAUTIFULby TREASURE  Lyrics.mp3"); // También acepta .ogg
Mix_PlayMusic(musica, -1); // -1 = loop infinito

    SDL_Delay(20000); // Mantener ventana abierta por 20 segundos

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}