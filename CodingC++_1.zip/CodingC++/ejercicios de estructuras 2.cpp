#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

/*Ejercicio 4: Hacer un arreglo de
 estructura llamada atleta para
  N atletas que contenga los 
  siguientes campos:
   nombre, país, numero_medallas.
    y devuelva los datos 
    (Nombre, país) del atleta que ha
     ganado el mayor número de 
     medallas.*/

struct atleta{
    char nombre[20];
    char pais[20];
    int num_med;
};
int main()
{
    int n;
    struct atleta atletas[20];
    cout << "Programa de gestion para verificar el atleta con mayor número de medallas. \n-----\n" <<endl;
    cout<<"introduce la cantidad de atletas: ";
    cin>>n;
    for(int i=0; i<n; i++){
        fflush(stdin);
        getch();
        cout << "introduzca el nombre:" << endl;
        cin.getline(atletas[i].nombre, 20, '\n');
        cout << "introduzca el genero:" << endl;
        cin.getline(atletas[i].pais, 20, '\n');
        cout << "introduzca el número de medallas:" << endl;
        cin>>atletas[i].num_med;
        cout<<"\n------\n";
    };
    float may=0;
    float men=99999999999999;
    int pos_may;
    int pos_men;
    
    //código para encontrar el mayor
    for(int i=0; i<n; i++){
        if(atletas[i].num_med > atletas[i+1].num_med)
        {
            may = atletas[i].num_med;
            pos_may = i;
        }
    };
    
    
    
    //impresión de los empleados
    cout << "lista de empleados\n_-_-_-_-_-_-_-__-_-_-\n" << endl;
    for(int i=0; i<n; i++){
       cout << "_-_-_-__-_-_-_-_-" << endl;
        cout<<"nombre: "<<atletas[i].nombre<<endl;
        cout<<"genero: "<<atletas[i].pais<<endl;
        cout<<"sueldo: "<<atletas[i].num_med<<endl;
        cout << "_-_-_-__-_-_-_-_-" << endl;
    };
    
    cout<<"El atleta com mayor número de medallas es: "<< atletas[pos_may].nombre<<endl;
    cout << "_-_-_-_-_-_-_-_-" << endl;
    
    getch();
    return 0;
};