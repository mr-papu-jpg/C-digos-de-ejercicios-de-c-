#include <iostream>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
using namespace std;

//prototipos de funcion
void pedirNotas();
void mostrarNotas();

//variables globales
int numCalif, *calif;
int cant;
struct alumno{
	char nombre[20];
}alumnos[100];

int main(){
    cout << "Ingrese la cantidad de alumnos: " << endl;
    cin>> cant;
    getch();
    for(int i=0; i<cant; i++){
        fflush(stdin);
    	cout << "Ingrese nombre: ";
    	cin.getline(alumnos[i].nombre, 20, '\n');
    }
    
    
    pedirNotas();
    mostrarNotas();
    
    delete [] calif;
}

void pedirNotas(){
	numCalif=cant;
    
    calif = new int[numCalif];
    
    for(int i=0; i<numCalif; i++){
    	cout << "Ingrese una nota de "<< alumnos[i].nombre<<": " << endl;
        cin>>calif[i];
    }
}

void mostrarNotas(){
	cout << "\n~~~~~~~~~~~\nNotas de los alumnos: \n" << endl;
    for(int i=0; i<numCalif; i++){
    	cout <<alumnos[i].nombre<< endl;
        cout << calif[i] << endl;
    }
}