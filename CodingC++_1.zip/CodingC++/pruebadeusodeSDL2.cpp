#include <SDL2/SDL.h>

#define WIDTH 640
#define HEIGHT 480
#define TILE 40

int main() {
    SDL_Init(SDL_INIT_VIDEO);

    SDL_Window* window = SDL_CreateWindow("Patrón SDL",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        WIDTH, HEIGHT, SDL_WINDOW_SHOWN);

    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    for (int y = 0; y < HEIGHT; y += TILE) {
        for (int x = 0; x < WIDTH; x += TILE) {
            SDL_SetRenderDrawColor(renderer,
                (x * 255 / WIDTH),
                (y * 255 / HEIGHT),
                ((x + y) * 255 / (WIDTH + HEIGHT)),
                255);
            SDL_Rect rect = { x, y, TILE, TILE };
            SDL_RenderFillRect(renderer, &rect);
        }
    }

    SDL_RenderPresent(renderer);

    SDL_Event e;
    int corriendo = 1;
    while (corriendo) {
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) {
                corriendo = 0;
            }
        }
        SDL_Delay(10);
    }

(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}