#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

/*Ejercicio 3: Realizar un programa que lea un arreglo
 de estructuras los datos de N empleados de la empresa y 
 que imprima los datos del empleado con mayor y menor salario.
*/

struct empleado{
    char nombre[20];
    int edad;
    char genero[20];
    float sueldo;
};
int main()
{
    int n;
    struct empleado empleados[10];
    cout << "Programa de gestion para verificar que empleado tiene sueldo mayor y sueldo menor." <<endl;
    cout<<"introduce la cantidad de empleados a comparar: ";
    cin>>n;
    for(int i=0; i<n; i++){
        fflush(stdin);
        cout << "introduzca el nombre:" << endl;
        getch();
        cin.getline(empleados[i].nombre, 20, '\n');
        cout << "introduzca la edad:" << endl;
        cin>>empleados[i].edad;
        getch();
        cout << "introduzca el genero:" << endl;
        cin.getline(empleados[i].genero, 20, '\n');
        cout << "introduzca el sueldo:" << endl;
        cin>>empleados[i].sueldo;
        cout<<"\n------\n";
    };
    float may=0;
    float men=99999999999999;
    int pos_may;
    int pos_men;
    
    //código para encontrar el mayor
    for(int i=0; i<n; i++){
        if(empleados[i].sueldo > empleados[i+1].sueldo)
        {
            may = empleados[i].sueldo;
            pos_may = i;
        }
    };
    
    //código para encontrar el menor
    for(int i=0; i<n; i++){
        if(empleados[i].sueldo < empleados[i+1].sueldo)
        {
            men = empleados[i].sueldo;
            pos_men = i;
        };
    };
    
    //impresión de los empleados
    cout << "lista de empleados\n_-_-_-_-_-_-_-__-_-_-\n" << endl;
    for(int i=0; i<n; i++){
        cout<<"nombre: "<<empleados[i].nombre<<endl;
        cout<<"edad: "<<empleados[i].edad<<endl;
        cout<<"genero: "<<empleados[i].genero<<endl;
        cout<<"sueldo: "<<empleados[i].sueldo<<endl;
        cout << "_-_-_-__-_-_-_-_-" << endl;
    };
    
    cout<<"El empleado con sueldo mayor: "<< empleados[pos_may].nombre<<endl;
    cout<<"El empleado con sueldo menor: "<< empleados[pos_men].nombre<<endl;
    cout << "_-_-_-_-_-_-_-_-" << endl;
    
    getch();
    return 0;
};