#include<iostream>
#include<conio.h>
using namespace std;

void tiempo(int totalSeg, int& hor, int& min, int& seg);

int main(){
	int a;
    int hor=0 , min=0, seg=0;
    cout<<"Escriba cantidad de segundos: ";
    cin >> a;
    
    tiempo(a, hor, min, seg);
    
    cout<<"horas: "<<hor<<"\nminutos: "<< min <<"\n segundos: "<<seg<< endl;
    
    getch();
    return 0;
}

void tiempo(int totalSeg, int& hor, int& min, int& seg){
	seg= totalSeg;
    if(seg>=60){
    	min= totalSeg/60;
        if(min>=60){
        	hor=min/60;
        }
    }
}