#include<iostream>
#include<conio.h>
using namespace std;

void carga_vec(int vec[], int tam);
int vec_sum(int vec[], int tam);

int main(){
	const int TAM=5;
    int vec[TAM];
    carga_vec(vec, TAM);
    cout<<"La sumabde todos los elementos es: "<<vec_sum(vec, TAM)<<endl;
    
    getch();
    return 0;
}

void carga_vec(int vec[], int tam){
	int n;
    for(int x=0; x<tam; x++){
    	cin>>n;
        vec[x]=n;
    }
}

int vec_sum(int vec[], int tam){
	int sum=0;
    
    for(int x=0;x<tam; x++){
    	sum+=vec[x];
    }
    return sum;
}