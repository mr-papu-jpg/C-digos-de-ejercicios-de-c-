#include<iostream>
#include<conio.h>
using namespace std;

void intercambio(int&, int&);

int main(){
	int a, b;
    
    cout<<"Escriba valores a ingresar: ";
    cin >> a >> b;
    
    intercambio(a, b);
    
    cout<<"a ahora es: "<<a<<" b ahora es: "<<b;
    
    getch();
    return 0;
}

void intercambio(int& a , int& b){
	
    int aux=0;
    
    aux=a;
    a=b;
    b=aux;
}