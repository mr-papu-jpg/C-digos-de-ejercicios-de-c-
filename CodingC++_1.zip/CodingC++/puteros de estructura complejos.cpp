#include <iostream>
#include <stdlib.h>
#include <conio.h>
using namespace std;

int num_estudiantes;

//creacion de la estructura
struct Estudiante {
    char nombre[30];
    float notas[3];
}*estudiantes;


//prototipos de funcion
void pedirDatos();
void mostrarDatos();
void mejorPromedio();

int main(){
	pedirDatos();
    mostrarDatos();
    mejorPromedio();
    
    //eliminacion de la memoria
    delete[] estudiantes;
    
    getch();
    return 0;
}

void pedirDatos(){
	cout << "Digite el numero de estudiantes: ";
    cin>>num_estudiantes;
    
    estudiantes = new struct Estudiante[num_estudiantes];
    cout << "\n<><><><><><>\n" << endl;
    for(int i=0; i<num_estudiantes;i++){
    	cout<<"DIGITE EL NOMBRE: ";
        getch();
        fflush(stdin);
        cin.getline((estudiantes+i)->nombre, 30, '\n');
        cout << "DIGITE EL PROMEDIOS: ";
        for(int j=0; j<3;j++){
        	cout << "\nDigite nota " << j+1 <<":";
            cin>>(estudiantes+i)->notas[j];
            cout << "\n~~~~~~~~" << endl;
        }
        cout << "\n|<><><><><><>|\n" << endl;
    }
}

void mostrarDatos(){
	for(int i=0; i<num_estudiantes;i++){
    	cout<<"NOMBRE: "<< (estudiantes+i)->nombre<< endl;
        for(int j=0; j<3;j++){
        	cout << "NOTA " << i <<":" <<(estudiantes+i)->notas[j]<<endl;
            cout << "\n~~~~~~~~" << endl;
        }
    }
}

void mejorPromedio(){
	int exp_may=0;
    int nots_n[num_estudiantes][3];
    int prm_f[num_estudiantes];
    //calculo para las notas de los alumnos
    for(int i=0;i< num_estudiantes; i++){
    	for(int j=0;j<3;j++){
        	nots_n[i][j]=(estudiantes+i)->notas[j];
        }
        prm_f[i]=(nots_n[i][0]+nots_n[i][1]+nots_n[i][2])/3;
    }
    
    //verificar nota mayor
    cout << "\nVerificacion para las notas... " << endl;
    int may=0;
    int pos;
    for(int i=0; i<num_estudiantes; i++){
    	if(prm_f[i]>may){
        	may=prm_f[i];
            pos=i;
        }
    }
    
    cout << "\n~~~~~~~\nLa nota mayor es "<< may << " del estudiante: "<<(estudiantes+pos)->nombre<< endl;
}