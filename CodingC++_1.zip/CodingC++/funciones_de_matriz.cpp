#include<iostream>
#include<conio.h>
using namespace std;

void carga_mat(int mat[][3], int tam);
void men_filas(int mat[][3],int tam);

int main(){
	const int TAM=3;
    int mat[TAM][TAM];
    
    carga_mat(mat, TAM);
    men_filas(mat, TAM);
    
    getch();
    return 0;
}

void carga_mat(int mat[][3], int tam){
	int n;
    for(int y=0; y<tam; y++){
    	for(int x=0; x<tam; x++){
    		cout<<"ingrese numero: "; cin>>n;
        	mat[y][x]=n;
        }    
    }
}

void men_filas(int mat[][3],int tam){
	int men_fils[tam];
    
    for(int y=0; y<tam; y++){
    	for(int x=0; x<tam; x++){
        	if(mat[y][x]<mat[y][x+1]){
            	men_fils[y]=mat[y][x];
            }
        }
    }
    
    cout << "Los numeros menores de las filas: " << endl;
    for(int x=0; x<tam; x++){
    	cout << men_fils[x] <<" ";
    }
}