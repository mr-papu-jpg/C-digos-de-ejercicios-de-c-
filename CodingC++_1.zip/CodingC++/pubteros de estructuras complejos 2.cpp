#include <iostream>
#include <stdlib.h>
#include <conio.h>
using namespace std;

int num_productos;

//creacion de la estructura
struct Producto {
    int id;
    char nombre[50];
    float precio;
}*p_procd;


//prototipos de funcion
void pedirDatos();
void mostrarDatos();
void ordenarProductos();
void totalPrecio();

int main(){
	pedirDatos();
    mostrarDatos();
    ordenarProductos();
    mostrarDatos();
    totalPrecio();
    
    //eliminacion de la memoria
    delete[] p_procd;
    
    getch();
    return 0;
}

void pedirDatos(){
	cout << "Digite el numero de productos: ";
    cin>>num_productos;
    
    p_procd = new struct Producto[num_productos];
    cout << "\n<><><><><><>\n" << endl;
    for(int i=0; i<num_productos;i++){
    	cout << "Digite la ID: " << endl;
        cin >>(p_procd+i)->id;
        cout << "Digite el nombre: "<<endl;
        getch();
        fflush(stdin);
        cin.getline((p_procd+i)->nombre, 50, '\n');
        cout << "Digite el precio: " << endl;
        cin >>(p_procd+i)->precio;
        cout << "\n~~~~~~~~" << endl;
    }
}

void mostrarDatos(){
	for(int i=0; i<num_productos;i++){
    	cout<<"ID: "<<(p_procd+i)->id<< endl;
        cout<<"Nombre: "<<(p_procd+i)->nombre<< endl;
        cout<<"Precio: "<<(p_procd+i)->precio<< endl;
        cout << "\n<><><><><><>\n" << endl;
    }
}

void totalPrecio(){
	int total=0;
    for(int i=0; i<num_productos; i++){
    	total+=(p_procd+i)->precio;
    }
    
    cout << "El precio total acomulado es: " <<total<< endl;
}

void ordenarProductos(){
	int aux;
    for(int i=0; i<num_productos-1; i++){
    	if((p_procd+i)->precio>(p_procd+(i+1))->precio){
    		aux=(p_procd+i)->precio;
        	(p_procd+i)->precio=(p_procd+(i+1))->precio;
        	(p_procd+(i+1))->precio=aux;
        }    
    }
}