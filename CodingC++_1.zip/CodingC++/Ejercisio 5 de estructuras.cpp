#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

/*Ejercicio 5: Hacer 2 estructuras una llamada 
promedio que tendrá los siguientes campos: 
nota1, nota2, nota3; y otro llamada alumno 
que tendrá los siguientes miembros: nombre, 
sexo, edad; hacer que la estructura promedio 
este anidada en la estructura alumno, luego 
pedir todos los datos para un alumno, luego 
calcular su promedio, y por ultimo imprimir 
todos sus datos incluidos el promedio.
*/

struct promedio{
	float nota1;
    float nota2;
    float nota3;
};

struct alumno{
	char nombre[20];
    char sexo[20];
    int edad;
    struct promedio promd;
}alumno1;

int main(){
	cout<<"Programa para sacar promedio de un alumno:\n -_-_-_-_-\n";
    cout<<"Introdusca el nombre"<<endl; cin.getline(alumno1.nombre, 20, '\n');
    cout<<"Introduzca sexo"<<endl; cin.getline(alumno1.sexo, 20, '\n');
    cout<<"Introduzca edad"<<endl; cin>>alumno1.edad;
    cout << "introduzca todo su promedio" << endl;
    cout << "<1>=" << endl;
    cin>>alumno1.promd.nota1;
    cout << "~~~~~~" << endl;
    cout << "<2>=" << endl;
    cin>>alumno1.promd.nota2;
    cout << "~~~~~~" << endl;
    cout << "<3>=" << endl;
    cin>>alumno1.promd.nota3;
    cout << "~~~~~~" << endl;
    
    float promdem =(alumno1.promd.nota1+alumno1.promd.nota2+alumno1.promd.nota3)/3;
    
    cout << "impresion de datos: " << endl;
    cout << "~~~~~~" << endl;
    cout << "NOMBRE: " <<alumno1.nombre<< endl;
    cout << "~~~~~~" << endl;
    cout << "SEXO: " <<alumno1.sexo<< endl;
    cout << "~~~~~~" << endl;
    cout << "EDAD: " <<alumno1.edad<< endl;
    cout << "~~~~~~" << endl;
    cout << "PROMEDIO: " <<promdem<< endl;
    
    getch();
    return 0;
};