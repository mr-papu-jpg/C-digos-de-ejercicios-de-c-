#include <iostream>
#include <string>
using namespace std;

int main() {
    string texto;
    cout << "Ingresa una cadena de texto: ";
    getline(cin, texto);

    // Contadores de vocales
    int a = 0, e = 0, i = 0, o = 0, u = 0;

    // Puntero al primer carácter de la cadena
    const char* ptr = texto.c_str();

    while (*ptr != '\0') {
        switch (tolower(*ptr)) {
            case 'a': a++; break;
            case 'e': e++; break;
            case 'i': i++; break;
            case 'o': o++; break;
            case 'u': u++; break;
        }
        ptr++; // Avanzar el puntero
    }

    cout << "\nFrecuencia de vocales:\n";
    cout << "a: " << a << "\ne: " << e << "\ni: " << i;
    cout << "\no: " << o << "\nu: " << u << endl;

    return 0;
}