//ejemplo de polimorfismo
#include <iostream>
#include <stdlib.h>
using namespace std;

class Animal{
	private:
    	string nombre;
        string raza;
    public:
    	Animal(string,string);//contructor
        virtual void comer();//metodo polimorfo    
};

class Humano: public Animal{
	private:
    	string profecion;
    public:
    	Humano(string,string,string);
        void comer();    
};

class Perro: public Animal{
	private:
        string especialidad;
    public:
    	Perro(string,string,string);
        void comer();    
};

Animal :: Animal(string _nombre,string _raza){
	nombre=_nombre;
    raza=_raza;
}

Humano :: Humano(string _nombre, string _raza, string _profecion) : Animal(_nombre, _raza){
	profecion=_profecion;
}

Perro :: Perro(string _nombre, string _raza, string _especialidad) : Animal(_nombre, _raza){
	especialidad=_especialidad;
}

void Animal :: comer(){
	cout <<nombre<<" esta comiendo";
}

void Humano:: comer() {
	Animal::comer();
    cout << " cereal por la maniana" << endl;
}

void Perro:: comer() {
	Animal::comer();
    cout << " perrarina en su taza" << endl;
}
int main(){
	Animal *vector[3];
    
    vector[0]=new Humano("Alejandro", "Blanco", "Ingeniero");
    vector[1]=new Humano("Maria", "Blanco", "Doctora");
    vector[2]=new Perro("Kenai", "Calle", "Vigilar");
    
    vector[0]->comer();
    cout << "\n";
    vector[1]->comer();
    cout << "\n";
    vector[2]->comer();
    
    return 0;
}