#include<iostream>
#include<conio.h>
using namespace std;

void com_ordcress(int vec[], int tam);
void carga_vec(int vec[], int tam);

int main(){
	const int TAM=5;
    int vec[TAM];
    carga_vec(vec, TAM);
    com_ordcress(vec, TAM);
    
    getch();
    return 0;
}

void carga_vec(int vec[], int tam){
	int n;
    for(int x=0; x<tam; x++){
    	cout<<"ingrese numero: "; cin>>n;
        vec[x]=n;
    }
}

void com_ordcress(int vec[], int tam){
	bool comp=false;
    for(int x=1; x<tam; x++){
    	if(vec[x]>vec[x+1]){
        	comp=true;
        }
    }
    
    if(comp==true){
    	cout<<"El vector esta ordenado";
    }
    if(comp==false){
    	cout << "El vector no esta ordenado" << endl;
    }
}