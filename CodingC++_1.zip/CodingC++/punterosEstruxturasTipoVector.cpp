#include <iostream>
#include <conio.h>
using namespace std;

struct Alumno{
	char nombre[30];
    int edad;
    float promedio;
}alumno[3], *puntero_alumno=alumno;

//prototipo de funcion
void pedirDatos();
void calcularMejorPromedio(Alumno *);

int main(){
	pedirDatos();
    calcularMejorPromedio(puntero_alumno);
    
    getch();
    return 0;
}

void pedirDatos(){
	for(int i=0; i<3;i++){
    	fflush(stdin);
    	cout << "Digite su nombre: " << endl;
        cin.getline((puntero_alumno+i)->nombre, 30, '\n');
        cout << "Digite su edad: " << endl;
        cin >> (puntero_alumno+i)->promedio;
        cout << "Digite el promedio: " << endl;
        cin >> (puntero_alumno+i)->promedio;
        cout << "\n~~~~~~~~\n" << endl;
        getch();
    }
}

void calcularMejorPromedio(Alumno *puntero_alumno){
	float mayor=0.0;
    int pos=0;
    
    for(int i=0; i<3; i++){
    	if((puntero_alumno+i)->promedio>mayor){
        	mayor=(puntero_alumno+i)->promedio;
            pos=i;
        }
    }
    
    //Impriendo datos del alumno
    cout<<"\n El Alumno con mejor promedio es: \n";
    cout << "Nombre: \n" <<(puntero_alumno+pos)->nombre<< endl;
}