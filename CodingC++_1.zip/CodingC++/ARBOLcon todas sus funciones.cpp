//hacer un programa que almacene los
//datos de los clientes de un banco, los almacene 
//en una cola, y por ultimo muestre el orden de los
//clientes en orden correcto.

#include<iostream>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
using namespace std;

struct Nodo {
	int dato;
    Nodo *der;
    Nodo *izq;
    Nodo *padre;
};

//prototiopos de las funciones
void menu();
Nodo *crearNodo(int n,Nodo *padre);
void insertarNodo(Nodo *&arbol, int n,Nodo *padre);
void mostrarArbol(Nodo *arbol, int cont);
bool busqueda(Nodo *arbol, int n);
void preOrden(Nodo *arbol);
void inOrden(Nodo *arbol);
void postOrden(Nodo *arbol);
void eliminar(Nodo *arbol, int n);
Nodo *minimo(Nodo *arbol);
void reemplazar(Nodo *arbol, Nodo *nuevo_nodo);
void destruirNodo(Nodo *nodo);
void eliminarNodo(Nodo *nodoEliminar);


int main(){
    menu();
    
    getch();
    return 0;
}

void menu(){
	int opcion, dato, contador=0;
    Nodo *arbol=NULL;
    
    do{
    	cout << "\t.||MENU||\n";
        cout << "1>>Insertar elementos al arbol\n";
        cout << "2>>Mostrar elementos al arbol\n";
        cout << "3>>Buscar elementos al arbol\n";
        cout << "4>>Mostrar elementos al arbol en preORDEN\n";
        cout << "5>>Mostrar elementos al arbol en inORDEN\n";
        cout << "6>>Mostrar elementos al arbol en postORDEN\n";
        cout << "7>>Eliminar elementos al arbol\n";
        cout << "8>>Salir\n>> ";
        cin >> opcion;
        
        switch(opcion){
        	case 1: cout<<"\nDigite un numero: ";
        			cin >> dato;
        	        insertarNodo(arbol, dato, NULL);
        	        cout<<"\n";
        	        break;
            case 2: mostrarArbol(arbol, contador);
					cout << "\nPresiona Enter para continuar...";
					cin.ignore();
					cin.get();
                    break;
            case 3: cout << "\nDigite numero a buscar: ";
            		cin >> dato;
            		if(busqueda(arbol, dato)){
                    	cout << "El elemento fue encontrado." << endl;
                    }else{
                    	cout << "El elemento no fue encontrado."<<endl;
                    }
                    cout << "\nPresiona Enter para continuar...";
					cin.ignore();
					cin.get();
                    break;
            case 4: preOrden(arbol);
					cout << "\nPresiona Enter para continuar...";
					cin.ignore();
					cin.get();
                    break;
			case 5: inOrden(arbol);
					cout << "\nPresiona Enter para continuar...";
					cin.ignore();
					cin.get();
                    break;
			case 6: postOrden(arbol);
					cout << "\nPresiona Enter para continuar...";
					cin.ignore();
					cin.get();
                    break;
            case 7: cout << "\nDigite elemento a eliminar";  
            		cin >> dato;
                    eliminar(arbol,dato);
                    cin.ignore();
					cin.get();
                    break;
        }
        cout << "\033[2J\033[1;1H";
    }while(opcion!=8);
}

Nodo *crearNodo(int n, Nodo *padre){
	Nodo *nuevo_nodo=new Nodo();
    
    nuevo_nodo->dato=n;
    nuevo_nodo->der=NULL;
    nuevo_nodo->izq=NULL;
    nuevo_nodo->padre=padre;
    
    return nuevo_nodo;
}

void insertarNodo(Nodo *&arbol, int n, Nodo *padre){
	if(arbol==NULL){
    	Nodo *nuevo_nodo=crearNodo(n, padre);
        arbol=nuevo_nodo;
    }
    else{ //si el arbol tiene uno o mas nodos
    	int valorRaiz=arbol->dato;
        if(n<valorRaiz){
        	insertarNodo(arbol->izq,n, arbol);
        }
        else{
        	insertarNodo(arbol->der,n, arbol);
        }
    }    
}

void mostrarArbol(Nodo *arbol, int cont){
	if(arbol==NULL){
    	return;
    }
    else{
    	mostrarArbol(arbol->der, cont+1);
        for(int i=0; i<cont; i++){
        	cout << " ";
        }
        cout <<arbol->dato<< endl;
        mostrarArbol(arbol->izq,cont+1);
    }
}

bool busqueda(Nodo *arbol, int n){
	if(arbol==NULL){
    	return false;
    }
    else if(arbol->dato==n){
    	return true;
    }
    else if(n<arbol->dato){
    	return busqueda(arbol->izq, n);
    }
    else{
    	return busqueda(arbol->der, n);
    }
}

void preOrden(Nodo *arbol){
	if(arbol==NULL){
    	return;
    }else{
    	cout<<arbol->dato<<"-";
        preOrden(arbol->izq);
        preOrden(arbol->der);
    }
}

void inOrden(Nodo *arbol){
	if(arbol==NULL){
    	return;
    }else{
    	inOrden(arbol->izq);
        cout<<arbol->dato<<"-";
        inOrden(arbol->der);
    }
}

void postOrden(Nodo *arbol){
	if(arbol==NULL){
    	return;
    }else{
    	postOrden(arbol->izq);
        postOrden(arbol->der);
        cout <<arbol->dato<<"-";
    }
}

void eliminar(Nodo *arbol, int n){
	if(arbol==NULL){
    	return;
    }else if(n<arbol->dato){
    	eliminar(arbol->izq,n);
    } 
    else if(n<arbol->dato){
    	eliminar(arbol->der,n);
    }else{
    	eliminarNodo(arbol);
    }
}

//funcion auxiliar para encontrar el menor
Nodo *minimo(Nodo *arbol){
	if(arbol=NULL){
    	return NULL;
    }
    if(arbol->izq){
    	return minimo(arbol->izq);
    }else{
    	return arbol;
    }
}

//funcion auxikiar para remplazar los nodos
void reemplazar(Nodo *arbol, Nodo *nuevo_nodo){
	if(arbol->padre){
    	if(arbol->dato==arbol->padre->izq->dato){
        	arbol->padre->izq=nuevo_nodo;
        }else if(arbol->dato==arbol->padre->der->dato){
        	arbol->padre->der=nuevo_nodo;
        }
    }
    if(nuevo_nodo){
    	nuevo_nodo->padre=arbol->padre;
    }
}

//funcion para destruir el nodo
void destruirNodo(Nodo *nodo){
	nodo->izq=NULL;
    nodo->der=NULL;
    
    delete nodo;
}

void eliminarNodo(Nodo *nodoEliminar){
	if(nodoEliminar->izq && nodoEliminar->der){
    	Nodo *menor=minimo(nodoEliminar->der);
        nodoEliminar->dato=menor->dato;
        eliminarNodo(menor);
    }
    else if(nodoEliminar->izq){
    	reemplazar(nodoEliminar,nodoEliminar->izq);
        destruirNodo(nodoEliminar);
    }
    else if(nodoEliminar->der){
    	reemplazar(nodoEliminar,nodoEliminar->der);
        destruirNodo(nodoEliminar);
    }else{
    	reemplazar(nodoEliminar,NULL);
        destruirNodo(nodoEliminar);
    }
}