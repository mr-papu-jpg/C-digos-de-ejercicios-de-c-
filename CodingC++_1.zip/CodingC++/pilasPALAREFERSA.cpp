#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
using namespace std;

struct Nodo{
	char caracter;
    Nodo *siguiente;
};

void pushPila(Nodo *&, char caracter);
void popPila(Nodo *&, char &caracter);

int main(){
	Nodo *pila=NULL;
    char caracter;
    cout << "Digite palabra: " << endl;
	while((caracter=getch())!='\n'){
   	 pushPila(pila, caracter);
	}
    cout << "\n" << endl;
    while(pila!=NULL){
   	 popPila(pila, caracter);
        cout << caracter;
	}
    
    getch();
    return 0;
}

void pushPila(Nodo *&pila, char caracter){
	Nodo *nuevo_nodo=new Nodo();
    nuevo_nodo->caracter=caracter;
    nuevo_nodo->siguiente=pila;
    pila=nuevo_nodo;
    
    cout << caracter;
}

void popPila(Nodo *&pila, char &caracter){
	Nodo *aux=pila;
    caracter=aux->caracter;
    pila=aux->siguiente;
    delete aux;
}