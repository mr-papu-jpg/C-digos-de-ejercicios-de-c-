#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Sprites Animations/SpritesAnimations.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Sprites Animations/SpritesAnimations.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/Entity.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/Entity/Entity.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PhysicsBody/PhysicsBody.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/PhysicsBody/PhysicsBody.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/SystenKeyCodes/Touch joystick.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías_para_el_juego_v2/SystenKeyCodes/Touch joystick.cpp"

int main(int argc, char* argv[]) {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER | SDL_INIT_EVENTS | SDL_INIT_GAMECONTROLLER);
    IMG_Init(IMG_INIT_PNG);

    SDL_DisplayMode mode;
    SDL_GetCurrentDisplayMode(0, &mode);

    SDL_Window* window = SDL_CreateWindow("Prueba de Animación",
                                          SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                                          mode.w, mode.h, SDL_WINDOW_FULLSCREEN);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // ⚙️ Cargar Texturas
    SDL_Texture* spriteSheet = IMG_LoadTexture(renderer, "/storage/3807-15EE/DCIM/frames/Untitled 07-11-2025 05-48-37.png");
    if (!spriteSheet) SDL_Log("❌ Error: No se cargó la textura del sprite.");

    SDL_Texture* ringTex = IMG_LoadTexture(renderer, "/storage/3807-15EE/DCIM/frames/joystickRing.png");
    SDL_Texture* knobTex = IMG_LoadTexture(renderer, "/storage/3807-15EE/DCIM/frames/JoystickKnob.png");

    // 🎮 Configurar joystick
    TouchJoystick joystick;
    joystick.setTextures(ringTex, knobTex);
    joystick.setPosition(mode.w * 0.125f, mode.h * 0.85f, mode.h * 0.08f);
    joystick.setScreenSize(mode.w, mode.h);

    // 🕹️ Crear entidad
    Entity player(mode.w / 2 - 32, mode.h / 2 - 32, 64, 64, spriteSheet);
    player.animator().addAnimation("idle", {
        { {0, 0, 64, 64}, 0.3f }
    });
    player.playAnimation("idle");
    player.animator().addAnimation("run", {
    { {  0, 0, 64, 64 }, 0.1f },
    { { 64, 0, 64, 64 }, 0.1f },
    { {128, 0, 64, 64 }, 0.1f },
    { {192, 0, 64, 64 }, 0.1f },
    { {256, 0, 64, 64 }, 0.1f },
    { {320, 0, 64, 64 }, 0.1f },
    { {384, 0, 64, 64 }, 0.1f }
});

  Uint32 lastTicks = SDL_GetTicks();
bool running = true;

while (running) {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) running = false;
        joystick.handleEvent(event, renderer);
    }

    Uint32 currentTicks = SDL_GetTicks();
    float deltaTime = (currentTicks - lastTicks) / 1000.0f;
    lastTicks = currentTicks;

    joystick.update(deltaTime);

    SDL_Point input = joystick.getDirection();
    float speed = 200.0f;

    // 🏃 Aplicar movimiento al Entity
    player.rect().x += input.x * speed * deltaTime;
    player.rect().y += input.y * speed * deltaTime;

    // ⚙️ Actualizar animación
    bool isMoving = (input.x != 0 || input.y != 0);
    player.update(deltaTime, isMoving);

    SDL_SetRenderDrawColor(renderer, 40, 40, 60, 255);
    SDL_RenderClear(renderer);

    // 🎮 Dibujar joystick y sprite
    joystick.render(renderer);
    player.render(renderer);

    SDL_Rect box = {
        static_cast<int>(player.rect().x),
        static_cast<int>(player.rect().y),
        static_cast<int>(player.rect().w),
        static_cast<int>(player.rect().h)
    };
    
    SDL_RenderDrawRect(renderer, &box);

    SDL_RenderPresent(renderer);
}

    SDL_DestroyTexture(spriteSheet);
    SDL_DestroyTexture(ringTex);
    SDL_DestroyTexture(knobTex);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();

    return 0;
}