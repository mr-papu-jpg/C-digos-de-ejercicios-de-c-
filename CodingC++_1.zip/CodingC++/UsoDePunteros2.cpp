#include <iostream>
#include <stdlib.h>
#include <conio.h>
using namespace std;

//prototipo de funcion
void pedirNotas();
void mostrarNotas();

int numCalif,*calif;

int main() {
    pedirNotas();
    mostrarNotas();
    
    delete[]calif;//librando el espacio de memoria en bytes
    
    getch();
    return 0;
}

void pedirNotas(){
	cout << "Digite numero de calificaciones: " << endl;
    cin>>numCalif;
    
    calif=new int[numCalif];//Crear el arreglo
    
    for(int i=0; i<numCalif;i++){
    	cout << "Ingrese nota: " << endl;
        cin >> calif[i];
    }
}

void mostrarNotas(){
	cout<<"\n\nMostrando Notas del usuario: \n";
    for(int i=0; i<numCalif;i++){
    	cout << calif[i] << endl;
    }
}