#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías para el juego/PhysicsBody/PhysicsBody.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías para el juego/PhysicsBody/PhysicsBody.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías para el juego/Sprites Animations/SpriteAnimator.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías para el juego/Sprites Animations/SpriteAnimator.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías para el juego/SystenKeyCodes/TouchJoystick.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías para el juego/SystenKeyCodes/TouchJoystick.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías para el juego/SystenKeyCodes/TouchButton.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías para el juego/SystenKeyCodes/TouchButton.cpp"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías para el juego/SystenKeyCodes/KeyboardInput.h"
#include "/storage/3807-15EE/Codigos/c++/librerias creadas por mi/librerías para el juego/SystenKeyCodes/KeyboardInput.cpp"

#include <vector>
class Entity {
public:
    Entity(SDL_Texture* texture);
    void update(float dt, SDL_Point inputDir, int screenW, int screenH);
    void render(SDL_Renderer* renderer);

private:
    PhysicsBody body;
    SpriteAnimator animator;
};

Entity::Entity(SDL_Texture* texture)
    : body(400, 300, 64, 64), animator(texture) {
    animator.addAnimation("idle", { {{0, 0, 64, 64}, 0.2f}, {{64, 0, 64, 64}, 0.2f} });
    animator.addAnimation("run",  { {{0, 64, 64, 64}, 0.1f}, {{64, 64, 64, 64}, 0.1f}, {{128, 64, 64, 64}, 0.1f} });
}

void Entity::update(float dt, SDL_Point inputDir, int screenW, int screenH) {
    body.setVelocity(inputDir.x * 200, inputDir.y * 200);
    body.update(dt, screenW, screenH);

    if (inputDir.x != 0 || inputDir.y != 0)
        animator.play("run");
    else
        animator.play("idle");

    animator.update(dt);
}

void Entity::render(SDL_Renderer* renderer) {
    SDL_FRect rect = body.getRect();

    // Dibujo de depuración
    SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
    SDL_Rect debugRect = {
        static_cast<int>(rect.x + 0.5f),
        static_cast<int>(rect.y + 0.5f),
        static_cast<int>(rect.w + 0.5f),
        static_cast<int>(rect.h + 0.5f)
    };
    SDL_RenderFillRect(renderer, &debugRect);

    // Dibujo del sprite animado
    animator.render(renderer, rect.x, rect.y);
}


int main(int argc, char *argv[])
{
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER | SDL_INIT_EVENTS | SDL_INIT_GAMECONTROLLER);
    IMG_Init(IMG_INIT_PNG);
    SDL_DisplayMode mode;
    SDL_GetCurrentDisplayMode(0, &mode); // Obtiene resolución del dispositivo

    SDL_Window *window = SDL_CreateWindow("Sistema de Entrada",
                                          SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                                          mode.w, mode.h, SDL_WINDOW_FULLSCREEN);
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    SDL_Texture *spriteSheet = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_TARGET, 64, 64);
    SDL_SetRenderTarget(renderer, spriteSheet);
    SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255); // rojo sólido
    SDL_RenderClear(renderer);
    SDL_SetRenderTarget(renderer, nullptr);

    SDL_Texture *joystickRing = IMG_LoadTexture(renderer, "/storage/3807-15EE/DCIM/frames/joystickRing.png");
    SDL_Texture *joystickKnob = IMG_LoadTexture(renderer, "/storage/3807-15EE/DCIM/frames/JoystickKnob.png");
    SDL_Texture *buttonTex = IMG_LoadTexture(renderer, "/storage/3807-15EE/DCIM/frames/ButtonShoot.png");

    Entity player(spriteSheet);
    TouchJoystick joystick;
    joystick.setTextures(joystickRing, joystickKnob);
    joystick.setPosition(mode.w * 0.125f, mode.h * 0.85f, mode.h * 0.08f);

    TouchButton shootButton(buttonTex, {700, 450, 64, 64});
    KeyboardInput keyboard;

    Uint32 lastTicks = SDL_GetTicks();
    bool running = true;

    while (running)
    {
        SDL_Event event;
        while (SDL_PollEvent(&event))
        {
            if (event.type == SDL_QUIT)
                running = false;

            joystick.handleEvent(event, renderer); //eventos táctiles
            shootButton.handleEvent(event);
        }

        Uint32 currentTicks = SDL_GetTicks();
        float deltaTime = (currentTicks - lastTicks) / 1000.0f;
        lastTicks = currentTicks;
            joystick.update(deltaTime); //  actualiza animación del knob

        SDL_Point inputDir = joystick.getDirection();

        //Sobrescribe con teclado si se presionan teclas
        if (keyboard.isKeyPressed(SDL_SCANCODE_LEFT))
            inputDir.x = -1;
        if (keyboard.isKeyPressed(SDL_SCANCODE_RIGHT))
            inputDir.x = 1;
        if (keyboard.isKeyPressed(SDL_SCANCODE_UP))
            inputDir.y = -1;
        if (keyboard.isKeyPressed(SDL_SCANCODE_DOWN))
            inputDir.y = 1;

        player.update(deltaTime, inputDir, mode.w, mode.h);

        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255); // limpia fondo
        SDL_RenderClear(renderer);
        joystick.render(renderer);
        shootButton.render(renderer);
        player.render(renderer);
        SDL_RenderPresent(renderer);
    }

    SDL_DestroyTexture(spriteSheet);
    SDL_DestroyTexture(joystickRing);
    SDL_DestroyTexture(joystickKnob);
    SDL_DestroyTexture(buttonTex);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();

    return 0;
}