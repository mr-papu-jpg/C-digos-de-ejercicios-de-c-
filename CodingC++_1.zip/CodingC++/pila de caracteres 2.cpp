#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
using namespace std;

struct Nodo{
	char comando[30];
    Nodo *siguiente;
};

void pushPila(Nodo *&, char cm[30]);
void popPila(Nodo *&, char cm[30]);

int main(){
	Nodo *pila=NULL;
    char comando[30];
    int n;
    cout << "Ingrese la cantidad de comandos a disponer: ";
    cin>> n;
    cin.ignore();
	for(int i = 0; i < n; i++){
   	 cout << "~~~~~~~~~~~~~~" << endl;
 	   cout << "Digite el comando: ";
    	cin.getline(comando, 30);
   	 pushPila(pila, comando);
	}
    
    cout << "\nSacando los elementos de la pila: " << endl;
    for(int i=0; i<n;i++){
    	popPila(pila, comando);
        cout << comando << " -> ";
        if(pila==NULL){
        	cout << "NULL";
        }
    }
    
    getch();
    return 0;
}

void pushPila(Nodo *&pila, char cm[30]){
    Nodo *nuevo_nodo = new Nodo();
    strcpy(nuevo_nodo->comando, cm);
    nuevo_nodo->siguiente = pila;
    pila = nuevo_nodo;

    cout << "\tComando: " << cm << "\n ha sido agregado a la pila.\n";
}

void popPila(Nodo *&pila, char cm[30]){
    if (pila == NULL) return;
    Nodo *aux = pila;
    strcpy(cm, aux->comando);
    pila = aux->siguiente;
    delete aux;
}