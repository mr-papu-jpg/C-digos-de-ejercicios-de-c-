#include <iostream>
#include <stdlib.h>
using namespace std;

class Fecha{
     private: //atributos
         int dia, mes, anio;
     public:
         Fecha(int, int, int); //constructor
         Fecha(long); //constructor 2
         void mostrarFecha();      
};

//contructor 1
Fecha::Fecha(int _dia, int _mes, int _anio){
     anio=_anio;
     mes=_mes;
     dia=_dia;   
}

void Fecha::mostrarFecha(){
     cout<<"La forma es: "<<dia<<"/"<<mes<<"/"<<anio<<endl;   
}

//contructor 2
Fecha::Fecha(long fecha){
     anio=int (fecha/10000);
     mes= int ((fecha-anio*10000)/100);
     dia=int (fecha-anio*10000-mes*100);
}

int main(){
     Fecha hoy(9, 1, 2017);
     Fecha ayer(20170108);
     
     hoy.mostrarFecha();
     ayer.mostrarFecha();
    
     return 0;   
}