#include<iostream>
#include<conio.h>
using namespace std;

int funpot();

int main(){
	int n;
	n=funpot();
    cout<<"NUMERO ELEVADO ES: "<<n;
    
    getch();
    return 0;
}

int funpot(){
	int n;
    int n2;
    int n_elv=1;
	cout<<"ESCRIBA NUMERO A ELEVAR: "; cin>>n;
    cout<<"ESCRIBA NUMERO LA ELEVACION: "; cin>>n2;
    
    for(int x; x<n2; x++){
    	n_elv=n_elv*n;
    }
    
    return n_elv;
}