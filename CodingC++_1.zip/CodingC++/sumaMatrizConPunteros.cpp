#include<iostream>
#include<conio.h>
#include<stdlib.h>
using namespace std;

//prototipos de funcion
void pedirDatos();
void mostrarMatriz(int **, int, int);
void sumaMatriz(int **, int **, int, int);

int **puntero_matriz_1,**puntero_matriz_2,**puntero_matriz_sum,nFilas, nCol;

int main(){
	pedirDatos();
    mostrarMatriz(puntero_matriz_1, nFilas, nCol);
    mostrarMatriz(puntero_matriz_2, nFilas, nCol);
    sumaMatriz(puntero_matriz_1, puntero_matriz_2, nFilas, nCol);
    mostrarMatriz(puntero_matriz_sum, nFilas, nCol);
    //liberar memoria de la primera matriz
    for(int i=0; i<nFilas;i++){
    	delete[]puntero_matriz_1[i];
    }
    
    delete[] puntero_matriz_1;
    
    //liberar memoria de la segunda matriz
    for(int i=0; i<nFilas;i++){
    	delete[]puntero_matriz_2[i];
    }
    
    delete[] puntero_matriz_2;
    
    //liberar memoria de la suma matriz
    for(int i=0; i<nFilas;i++){
    	delete[]puntero_matriz_sum[i];
    }
    
    delete[] puntero_matriz_sum;
    
    getch();
    return 0;
}

void pedirDatos(){
	cout << "Digite el numero de filas: " << endl;
    cin >> nFilas;
    cout << "Digite el numero de columnas: " << endl;
    cin >> nCol;
    //reservar la memoria para la matriz dinamica 1
    puntero_matriz_1=new int *[nFilas];//reservar memoria para las filas
    for(int i=0; i<nFilas;i++){
    	puntero_matriz_1[i]=new int[nCol];//resevar memoria para las columnas
    }
    
    cout<<"\nDigitando elementos de la matriz: ";
    for(int i=0; i<nFilas; i++){
    	for(int j=0; j<nCol; j++){
    		cout<<"Digite un numero["<<i<<"]["<<j<<"]:";
        	cin >> *(*(puntero_matriz_1+i)+j);
        }
    }
    
    //reservar la memoria para la matriz dinamica 2
    puntero_matriz_2=new int *[nFilas];//reservar memoria para las filas
    for(int i=0; i<nFilas;i++){
    	puntero_matriz_2[i]=new int[nCol];//resevar memoria para las columnas
    }
    
    cout<<"\nDigitando elementos de la matriz: ";
    for(int i=0; i<nFilas; i++){
    	for(int j=0; j<nCol; j++){
    		cout<<"Digite un numero["<<i<<"]["<<j<<"]:";
        	cin >> *(*(puntero_matriz_2+i)+j);
        }
    }
}    

void mostrarMatriz(int **puntero_matriz, int nFilas, int nCol){
	cout<<"\n\nImprimiendo matriz: \n";
    for(int i=0; i<nFilas; i++){
    	for(int j=0; j<nCol; j++){
    		cout<<*(*(puntero_matriz+i)+j)<<" - ";
        }
        cout << "\n";
    }
}

void sumaMatriz(int **p_m1, int **p_m2, int nFilas, int nCol){
	 //reservar la memoria para la matriz dinamica 1
    puntero_matriz_sum=new int *[nFilas];//reservar memoria para las filas
    for(int i=0; i<nFilas;i++){
    	puntero_matriz_sum[i]=new int[nCol];//resevar memoria para las columnas
    }
    
    cout << "\n\nEjecutandobla suma..." << endl;
    for(int i=0; i<nFilas; i++){
    	for(int j=0; j<nCol; j++){
    		*(*(puntero_matriz_sum+i)+j)=*(*(puntero_matriz_1+i)+j)+*(*(puntero_matriz_2+i)+j);
        }
    }
}