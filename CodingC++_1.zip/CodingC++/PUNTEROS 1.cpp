#include<iostream>
#include<conio.h>
using namespace std;

void vef_primo(int*);

int main(){
	int n, *np;
    cout << "Ingrese numero a verificar" << endl;
    cin >> n;
    *np=n;
    vef_primo(np);
    
    getch();
    return 0;
}

void vef_primo(int *np){
	if(*np%2==0){
    	cout << "Es primo" << endl;
        cout << "Direccion de memoria: " << np << endl;
    }
    else
    {
    	cout << "No es primo" << endl;
        cout << "Direccion de memoria: " << np << endl;
    }    
}