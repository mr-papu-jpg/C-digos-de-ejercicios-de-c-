#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
#include <iostream>

int main(int argc, char* argv[]) {
    // Inicializa SDL Video y Audio
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        std::cerr << "Error al iniciar SDL: " << SDL_GetError() << std::endl;
        return 1;
    }

    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
        std::cerr << "Error al iniciar SDL_mixer: " << Mix_GetError() << std::endl;
        return 1;
    }

    SDL_Window* window = SDL_CreateWindow("Hola Mundo con voz",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_SHOWN);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    // Carga música
    Mix_Music* musica = Mix_LoadMUS("/storage/3807-15EE/Music/sonidos/voz_1.wav");
    if (!musica) {
        std::cerr << "Error al cargar la música: " << Mix_GetError() << std::endl;
    } else {
        Mix_PlayMusic(musica, 1);
    }

    // Carga sprites (letras) en texturas
    std::vector<SDL_Texture*> texturas;
    for (int i = 1; i <= 8; i++) {
        std::string path = "/storage/3807-15EE/DCIM/hola mundo sprites/" + std::to_string(i) + ".bmp";
        SDL_Surface* surface = SDL_LoadBMP(path.c_str());
        if (!surface) continue;

        SDL_Texture* textura = SDL_CreateTextureFromSurface(renderer, surface);
        SDL_FreeSurface(surface);
        if (textura) {
            texturas.push_back(textura);
        }
    }

    // Bucle principal
    bool running = true;
    SDL_Event event;
    while (running) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT)
                running = false;
        }

        SDL_RenderClear(renderer);

        for (int i = 0; i < texturas.size(); i++) {
            SDL_Rect destino = {30 + (i * 70), 200, 64, 64}; // Separar horizontalmente
            SDL_RenderCopy(renderer, texturas[i], NULL, &destino);
        }

        SDL_RenderPresent(renderer);
        SDL_Delay(2000);
    }

    // Libera recursos
    for (SDL_Texture* tex : texturas) {
        SDL_DestroyTexture(tex);
    }
    Mix_FreeMusic(musica);
    Mix_CloseAudio();
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}