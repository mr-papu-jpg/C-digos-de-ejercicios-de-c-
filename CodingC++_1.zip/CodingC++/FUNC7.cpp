#include<iostream>
#include<conio.h>
using namespace std;

void carga_vec(int vec[], int tam);
void cambiar_signo(int vec[], int tam);
void mostrar(int vec[], int tam);
void mostrar_impar(int vev[], int tam);

int main(){
	const int TAM=5;
    int vec[TAM];
    carga_vec(vec, TAM);
    mostrar(vec, TAM);
    cout << "\n\n" << endl;
    mostrar_impar(vec, TAM);
    
    getch();
    return 0;
}

void carga_vec(int vec[], int tam){
	int n;
    for(int x=0; x<tam; x++){
    	cout<<"ingrese numero: "; cin>>n;
        vec[x]=n;
    }
}

void cambiar_signo(int vec[], int tam){
    for(int x=0; x<tam; x++){
    	vec[x]*=-1;
    }
}

void mostrar(int vec[], int tam){
	for(int x=0; x<tam;x++){
    	cout << vec[x] << endl;
    }
}

void mostrar_impar(int vec[], int tam){
	int div[tam];
    for(int x=0; x<tam;x++){
    	if(vec[x]%2==0){
    		cout << vec[x] << endl;
        }    
    }
}