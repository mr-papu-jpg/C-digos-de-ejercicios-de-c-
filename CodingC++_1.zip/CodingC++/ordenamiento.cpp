#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
using namespace std;

struct Nodo{
	char caracter;
    Nodo *siguiente;
};

void pushPila(Nodo *&, char caracter);
void popPila(Nodo *&, char &caracter);
void equilibrarPila(Nodo *&);

int main(){
	Nodo *pila=NULL;
    char caracter;
    cout << "Digite cadena a calcular: " << endl;
	while((caracter=getch())!='\n'){
   	 pushPila(pila, caracter);
	}
    
    equilibrarPila(pila);
    while(pila==NULL){
   	 popPila(pila, caracter);
	}
    
    getch();
    return 0;
}

void pushPila(Nodo *&pila, char caracter){
	Nodo *nuevo_nodo=new Nodo();
    nuevo_nodo->caracter=caracter;
    nuevo_nodo->siguiente=pila;
    pila=nuevo_nodo;
    
    cout << caracter;
}

void popPila(Nodo *&pila, char &caracter){
	Nodo *aux=pila;
    caracter=aux->caracter;
    pila=aux->siguiente;
    delete aux;
}

void equilibrarPila(Nodo *&pila) {
    Nodo *pila_aux = NULL;
    bool equilibrado = true;

    while (pila != NULL) {
        char c;
        popPila(pila, c);

        if (c == '{' || c == '(') {
            // Si encontramos un apertura sin su cierre correspondiente
            equilibrado = false;
            break;
        } else if (c == '}' || c == ')') {
            pushPila(pila_aux, c);
        }
    }

    while (pila_aux != NULL && equilibrado) {
        char c;
        popPila(pila_aux, c);
        if ((c == '}' && pila != NULL && pila->caracter == '{') ||
            (c == ')' && pila != NULL && pila->caracter == '(')) {
            char temp;
            popPila(pila, temp);
        } else {
            equilibrado = false;
        }
    }

    if (equilibrado && pila == NULL && pila_aux == NULL) {
        std::cout << "\nEl cálculo está equilibrado." << std::endl;
    } else {
        std::cout << "\nEl cálculo no está equilibrado." << std::endl;
    }
}