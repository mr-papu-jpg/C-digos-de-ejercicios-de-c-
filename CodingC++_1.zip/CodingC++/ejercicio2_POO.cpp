#include <iostream>
#include <stdlib.h>

using namespace std;

class Persona{
     private: //atributos
         string nombre;
         int edad;
         
     public: //metodos
         Persona(string, int);//contructor
         void mostrarPersona();
};

class Alumno:public Persona{ //clase hija que hereda
    private: //atributos
        string codigoAlumno;
        float notaFinal;
        
    public: //metodos
        Alumno(string, int, string, float);//constructor de la clase
        void mostrarAlumno();
};

class Empleado : public Persona{ //clase hija que hereda
    private: //atributos
        string trabajo;
        float sueldo;
        
    public: //metodos
        Empleado(string, int, string, float);//constructor de la clase
        void mostrarEmpleado();
};

class Universitario:public Alumno{ //clase hija que hereda
    private: //atributos
        string carrera;
    public: //metodos
        Universitario(string, int, string, float, string);//constructor de la clase
        void mostrarUniversitario();
};


//contructor de la clase persona(clase padre)
Persona::Persona(string _nombre, int _edad){
        nombre=_nombre;
        edad=_edad;  
}

Alumno::Alumno(string _nombre, int _edad, string _codigoAlumno, float _notaFinal):Persona(_nombre, _edad){
     codigoAlumno=_codigoAlumno;
     notaFinal=_notaFinal;   
}

Empleado::Empleado(string _nombre, int _edad, string _trabajo, float _sueldo) : Persona(_nombre, _edad){
     trabajo=_trabajo;
     sueldo=_sueldo;   
}

Universitario :: Universitario(string _nombre, int _edad, string _codigoAlumno, float _notaFinal, string _carrera) :Alumno(_nombre, _edad, _codigoAlumno, _notaFinal){
	carrera= _carrera;
}

void Persona::mostrarPersona(){
    cout<<"Nombre: "<<nombre<<endl;
    cout<<"Edad: "<<edad<<endl;
}

void Alumno::mostrarAlumno(){
    mostrarPersona();
    cout<<"Cdigo de alumno: "<<codigoAlumno<<endl;
    cout<<"Nota Final: "<<notaFinal<<endl;
}

void Empleado::mostrarEmpleado(){
    mostrarPersona();
    cout<<"Trabajo del empleado: "<<trabajo<<endl;
    cout<<"Sueldo: "<<sueldo<<endl;
}

void Universitario :: mostrarUniversitario(){
	mostrarAlumno();
    cout << "Carrera: "<<carrera<< endl;
}

int main(){
     
     Alumno alm1("Pepe", 15, "236423" , 14.56);
     Empleado emp2("Roberto", 34, "Doctor", 2333.45);
     Universitario univ3("Angel", 21, "928833", 18.45, "Informatica");
     
     cout << "Mostrando datos:\n" << endl;
     alm1.mostrarAlumno();
     cout << "\n";
     emp2.mostrarEmpleado();
     cout << "\n";
     univ3.mostrarUniversitario();
     
     return 0;   
}