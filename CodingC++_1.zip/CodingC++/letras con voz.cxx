#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>
#include <cstdlib>
#include <ctime>

int main(int argc, char* argv[]) {
    SDL_Init(SDL_INIT_VIDEO);
    SDL_Window* window = SDL_CreateWindow("voz de prueba",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 640, 480, SDL_WINDOW_SHOWN);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    srand(static_cast<unsigned>(time(nullptr)));

    Uint32 lastTime = SDL_GetTicks();
for(int i=0; i<=8; i++){
		SDL_Surface* surface = SDL_LoadBMP("/storage/3807-15EE/DCIM/hola mundo sprites/"+i+".bmp");
	SDL_Texture* textura = SDL_CreateTextureFromSurface(renderer, surface);
	SDL_FreeSurface(surface);

	SDL_Rect destino = {30, 200+(i*5), 64, 64}; // Posición y tamaño en pantalla
	SDL_RenderCopy(renderer, textura, NULL, &destino);
}
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}