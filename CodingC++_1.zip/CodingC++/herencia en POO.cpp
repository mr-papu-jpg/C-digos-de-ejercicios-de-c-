#include <iostream>
#include <stdlib.h>

using namespace std;

class Persona{
     private: //atributos
         string nombre;
         int edad;
         
     public: //metodos
         Persona(string, int);//contructor
         void mostrarPersona();
};

class Alumno:public Persona{ //clase hija que hereda
    private: //atributos
        string codigoAlumno;
        float notaFinal;
        
    public: //metodos
        Alumno(string, int, string, float);//constructor de la clase
        void mostrarAlumno();
};

//contructor de la clase persona(clase padre)
Persona::Persona(string _nombre, int _edad){
        nombre=_nombre;
        edad=_edad;  
}

Alumno::Alumno(string _nombre, int _edad, string _codigoAlumno, float _notaFinal):Persona(_nombre, _edad){
     codigoAlumno=_codigoAlumno;
     notaFinal=_notaFinal;   
}

void Persona::mostrarPersona(){
    cout<<"Nombre: "<<nombre<<endl;
    cout<<"Edad: "<<edad<<endl;
}

void Alumno::mostrarAlumno(){
    mostrarPersona();
    cout<<"Cdigo de alumno: "<<codigoAlumno<<endl;
    cout<<"Nota Final: "<<notaFinal<<endl;
}

int main(){
     Alumno alumno1("Alejandro", 20,"12312312", 15.6);
     alumno1.mostrarAlumno();
     
     return 0;   
}