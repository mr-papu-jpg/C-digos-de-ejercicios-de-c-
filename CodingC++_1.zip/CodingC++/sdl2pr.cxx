#include <SDL2/SDL.h>

SDL_Window *ventana;
SDL_Renderer *renderer;

int main( int argc, char * argv[] ) {
    SDL_Init(SDL_INIT_EVERYTHING);

    ventana = SDL_CreateWindow("Mi primera ventana",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
            640, 480, SDL_WINDOW_SHOWN);
    renderer = SDL_CreateRenderer(ventana, -1, 0);

    SDL_Delay(5000);

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(ventana);
    SDL_Quit();
    return 0;
}