#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>

int main(int argc, char* argv[]) {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS);
    SDL_Window* window = SDL_CreateWindow("Nave táctil SDL2",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        640, 480, SDL_WINDOW_SHOWN);

    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    SDL_Surface* surface = SDL_LoadBMP("/storage/3807-15EE/Codigos/c++/proyectos de SDL/Nave-jugador.bmp");
    SDL_Texture* textura = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_FreeSurface(surface);

    SDL_Rect destino = {30, 200, 64, 64}; // Posición y tamaño inicial
    bool running = true;

    while (running) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    running = false;
                    break;

                case SDL_FINGERDOWN: {
                    // Convertir coordenadas normalizadas a píxeles
                    int x = static_cast<int>(event.tfinger.x * 640);
                    int y = static_cast<int>(event.tfinger.y * 480);

                    // Mover la nave al punto tocado (centro alineado)
                    destino.x = x - destino.w / 2;
                    destino.y = y - destino.h / 2;
                    break;
                }
            }
        }

        // Limpiar pantalla, dibujar y mostrar
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255); // fondo negro
        SDL_RenderClear(renderer);
        SDL_RenderCopy(renderer, textura, NULL, &destino);
        SDL_RenderPresent(renderer);

        SDL_Delay(16); // ~60 FPS
    }

    SDL_DestroyTexture(textura);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    return 0;
}