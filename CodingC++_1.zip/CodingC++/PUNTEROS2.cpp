#include<iostream>
#include<conio.h>
using namespace std;

int main(){
	int vec[5], *dir_vec;
    
    for(int x=0; x<5;x++){
    	cout << "Ingrese valor: " << endl;
        cin >>vec[x];
    }
    
    dir_vec=vec;
    
    cout << "Verificar cual es el menor" << endl;
    int men= vec[1];
    
    for(int x=0; x<5;x++){
    	if(*dir_vec<men){
        	men=*dir_vec;
        }
        dir_vec++;    
    }
    
    cout << "El valor menor es: " <<men<< endl;
    
    getch();
    return 0;
}