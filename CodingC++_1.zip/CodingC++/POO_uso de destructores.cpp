#include <iostream>
#include <stdlib.h>
#include <string.h>
using namespace std;

class Perro{
     private: //atributos
         string nombre, raza;
     public:
         Perro(string, string); //constructor
         ~Perro();//Desctructor
         void mostrarDatos();
         void jugar(); 
};

//contructor
Perro::Perro(string _nombre, string _raza){
    nombre= _nombre;
    raza= _raza;
}

Perro::~Perro(){}

void Perro::mostrarDatos(){
     cout<<"Nombre del perro: "<<nombre<<endl;
     cout<<"Raza del perro: "<<raza<<endl;
}

 void Perro::jugar(){
      cout<<"El perro "<<nombre<<" esta jugando."<<endl;
 }


int main(){
     Perro perro1("Fido", "Doberman");
     
     perro1.mostrarDatos();
     perro1.jugar();
     perro1.~Perro();
    
     return 0;   
}