#include <SDL2/SDL.h>
#include <iostream>

int main(int argc, char* argv[]) {
    // Inicializa SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cout << "Error al iniciar SDL: " << SDL_GetError() << std::endl;
        return 1;
    }

    // Crea la ventana
    SDL_Window* ventana = SDL_CreateWindow("Mi primer juego",
                                           SDL_WINDOWPOS_CENTERED,
                                           SDL_WINDOWPOS_CENTERED,
                                           800, 600,
                                           SDL_WINDOW_SHOWN);
    if (!ventana) {
        std::cout << "Error al crear la ventana: " << SDL_GetError() << std::endl;
        SDL_Quit();
        return 1;
    }

    // Crea el renderizador
    SDL_Renderer* renderizador = SDL_CreateRenderer(ventana, -1, SDL_RENDERER_ACCELERATED);
    if (!renderizador) {
        std::cout << "Error al crear el renderizador: " << SDL_GetError() << std::endl;
        SDL_DestroyWindow(ventana);
        SDL_Quit();
        return 1;
    }
    // Rellenamos el fondo con color
    SDL_SetRenderDrawColor(renderizador, 255, 0, 0, 255); // Rojo
    SDL_RenderClear(renderizador);
    SDL_RenderPresent(renderizador);

    // Espera 3 segundos antes de cerrar
    SDL_Delay(3000);

    // Limpieza
    SDL_DestroyRenderer(renderizador);
    SDL_DestroyWindow(ventana);
    SDL_Quit();
    return 0;
}    