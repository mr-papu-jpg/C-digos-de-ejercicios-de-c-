#include <iostream>
#include <stdlib.h>
#include <conio.h>
using namespace std;

int num_jugadores;

//creacion de la estructura
struct Jugador {
    char nombre[30];
    int nivel;
    int experiencia;
}*p_jugador;


//prototipos de funcion
void pedirDatos();
void mostrarDatos();
void jugadorMasEXP();

int main(){
	pedirDatos();
    mostrarDatos();
    jugadorMasEXP();
    
    //eliminacion de la memoria
    delete[] p_jugador;
    
    getch();
    return 0;
}

void pedirDatos(){
	cout << "Digite el numero de jugadores: ";
    cin>>num_jugadores;
    
    p_jugador = new struct Jugador[num_jugadores];
    
    for(int i=0; i<num_jugadores;i++){
    	cout<<"DIGITE EL NOMBRE: ";
        getch();
        fflush(stdin);
        cin.getline((p_jugador+i)->nombre, 30, '\n');
        cout << "DIGITE EL NIVEL: ";
        cin >>(p_jugador+i)->nivel;
        cout << "DIGITE EXPERIENCIA: ";
        cin >>(p_jugador+i)->experiencia;
        cout << "~~~~~~~~~~" << endl;
    }
}

void mostrarDatos(){
	for(int i=0; i<num_jugadores;i++){
    	cout<<"NOMBRE: "<< (p_jugador+i)->nombre<< endl;
        cout << "NIVEL: "<<(p_jugador+i)->nivel<<endl;
        cout << "EXPERIENCIA: "<<(p_jugador+i)->experiencia<<endl;
        cout << "~~~~~~~~~~" << endl;
    }
}

void jugadorMasEXP(){
	int exp_may=0;
    int pos_jugador;
    
    for(int i=0; i<num_jugadores;i++){
    	if((p_jugador+i)->experiencia*(p_jugador+i)->nivel>exp_may){
        	exp_may=(p_jugador+i)->experiencia*(p_jugador+i)->nivel;
            pos_jugador=i;
        }
    }
    cout << "El Jugador con mas experiencia es: "<<(p_jugador+pos_jugador)->nombre<< endl;
}