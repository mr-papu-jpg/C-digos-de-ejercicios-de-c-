#include <iostream>
#include <string>
using namespace std;

int main() {
    string texto;
    cout << "Ingresa una cadena de texto: ";
    getline(cin, texto);

    // Contadores de vocales
    int m = 0, n = 0, q = 0, p = 0, r = 0;

    // Puntero al primer carácter de la cadena
    const char* ptr = texto.c_str();

    while (*ptr != '\0') {
        switch (tolower(*ptr)) {
            case 'm': m++; break;
            case 'n': n++; break;
            case 'q': q++; break;
            case 'p': p++; break;
            case 'r': r++; break;
        }
        ptr++; // Avanzar el puntero
    }

    cout << "\nFrecuencia de Consonantes m,n,q,p,r:\n";
    cout << "m: " << m << "\nn: " << n << "\nq: " << q;
    cout << "\np: " << p << "\nr: " << r << endl;

    return 0;
}